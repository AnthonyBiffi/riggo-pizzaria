import { Injectable, Inject, BadRequestException } from '@nestjs/common';
import { v4 as uuid } from 'uuid';
import { HANA_CONNECTION } from '../database/hana.provider';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(@Inject(HANA_CONNECTION) private readonly conn: any) {}

  findAll(): Promise<any[]> {
    return new Promise((resolve, reject) => {
      this.conn.exec(
        `SELECT * FROM OFICINA_TRUSTED_ANTHONY.USERS`,
        (err: any, rows: any[]) => {
          if (err) return reject(err);
          resolve(rows);
        },
      );
    });
  }

  findOne(id: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.conn.exec(
        `SELECT * FROM OFICINA_TRUSTED_ANTHONY.USERS WHERE ID = ?`, [id],
        (err: any, rows: any[]) => {
          if (err) return reject(err);
          resolve(rows && rows.length > 0 ? rows[0] : null);
        },
      );
    });
  }

  async create(data: any): Promise<any> {
    const { name, email, password } = data;
    const id = uuid();

    const emailExist = await this.findByEmail(email);
    if (emailExist) throw new BadRequestException('Email já cadastrado');

    const hashed = await bcrypt.hash(password, 10);

    return new Promise((resolve, reject) => {
      const sql = `INSERT INTO OFICINA_TRUSTED_ANTHONY.USERS (ID, NAME, EMAIL, PASSWORD)
                   VALUES (?, ?, ?, ?)`;

      this.conn.exec(sql, [id, name, email, hashed], async (err: any) => {
        if (err) return reject(err);
        const inserted = await this.findOne(id);
        resolve(inserted);
      });
    });
  }

  findByEmail(email: string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.conn.exec(
        `SELECT * FROM OFICINA_TRUSTED_ANTHONY.USERS WHERE EMAIL = ?`,
        [email],
        (err: any, rows: any[]) => {
          if (err) return reject(err);
          resolve(rows && rows.length > 0 ? rows[0] : null);
        },
      );
    });
  }

  async update(id: string, data: any): Promise<any> {
    const { name, email, password } = data;

    let newPassword = password;

    if (password) {
      newPassword = await bcrypt.hash(password, 10);
    }

    const sql = `UPDATE OFICINA_TRUSTED_ANTHONY.USERS
                 SET NAME = ?,
                     EMAIL = ?,
                     PASSWORD = ?,
                     UPDATE_AT = CURRENT_TIMESTAMP
                 WHERE ID = ?`;

    return new Promise((resolve, reject) => {
      this.conn.exec(sql, [name, email, newPassword, id], (err: any) => {
        if (err) return reject(err);
        resolve({ id, name, email });
      });
    });
  }

  async forgotPassword(email: string): Promise<any> {
    const user = await this.findByEmail(email);
    if (!user) throw new BadRequestException("Email não encontrado");
    return { message: "OK" };
  }

  remove(id: string): Promise<boolean> {
    return new Promise((resolve, reject) => {
      this.conn.exec(
        `DELETE FROM OFICINA_TRUSTED_ANTHONY.USERS WHERE ID = ?`,
        [id],
        (err: any) => {
          if (err) return reject(err);
          resolve(true);
        },
      );
    });
  }
}
