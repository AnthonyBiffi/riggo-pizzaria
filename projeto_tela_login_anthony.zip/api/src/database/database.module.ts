import { Module } from '@nestjs/common';
import { hanaProvider } from './hana.provider';

@Module({
  providers: [hanaProvider],
  exports: [hanaProvider], 
})
export class DatabaseModule {}
