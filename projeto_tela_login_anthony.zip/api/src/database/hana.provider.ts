import * as hana from '@sap/hana-client';
import * as dotenv from 'dotenv'
import {Provider} from '@nestjs/common'
dotenv.config()

export const HANA_CONNECTION = 'HANA_CONNECTION'

export const hanaProvider: Provider = {
    provide: HANA_CONNECTION,
    useFactory: () => {
        const conn = hana.createConnection();

        conn.connect(
            {
            serverNode: process.env.HANA_HOST,
            uid: process.env.HANA_USER,
            pwd: process.env.HANA_PASSWORD
        },
        (err) => {
            if (err){
                console.log("erro ao conectar com o SAP HANA", err);                
            }else{
                console.log("conectado ao SAP HANA");
            }
        },
        );

        return conn;
    },
};