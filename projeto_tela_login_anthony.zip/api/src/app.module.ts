import { Module } from '@nestjs/common';
import { UsersModule } from './users/users.module';
import { AuthController } from './auth.controller';
import { DatabaseModule } from './database/database.module';

@Module({
  imports: [
    DatabaseModule,  
    UsersModule
  ],
  controllers: [AuthController],
})
export class AppModule {}
