import { Controller, Post, Get, Body, BadRequestException } from '@nestjs/common';
import { UsersService } from './users/users.service';
import * as bcrypt from 'bcrypt';

@Controller('api')
export class AuthController {
  constructor(private readonly usersService: UsersService) {}

  @Get('teste')
  teste() {
    return { ok: true, msg: 'API funcionando' };
  }

  @Post('login')
  async login(@Body() body: any) {
    const { username, password } = body;

    if (!username || !password) {
      throw new BadRequestException('email e password são obrigatórios.');
    }

    const user = await this.usersService.findByEmail(username);

    if (!user) {
      return { success: false, message: 'email não encontrado' };
    }

    const isValid = await bcrypt.compare(password, user.PASSWORD);

    if (!isValid) {
      return { success: false, message: 'Senha incorreta' };
    }

    return {
      success: true,
      message: 'Login bem-sucedido',
      user: {
        id: user.ID,
        name: user.NAME,
        email: user.EMAIL,
      },
    };
  }
}
